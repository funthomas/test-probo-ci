SET NAMES utf8;
DROP DATABASE IF EXISTS `probo_test`;
CREATE DATABASE `probo_test`;
USE `probo_test`;
DROP TABLE IF EXISTS `node`;
CREATE TABLE `node` (
  `id` int(11) NOT NULL,
  `node_name` varchar(45) DEFAULT NULL,
  `node_type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
INSERT INTO `node` (`id`, `node_name`, `node_type`)
VALUES
        (1, 'Testovaci', 'adresar');
